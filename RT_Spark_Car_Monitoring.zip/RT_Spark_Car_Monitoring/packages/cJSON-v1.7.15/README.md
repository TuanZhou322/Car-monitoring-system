# cJSON for RT-Thread

[中文页](README_ZH.md) | English

Ultralightweight JSON parser in ANSI C.

Offical repository: https://github.com/DaveGamble/cJSON

Maintenance: [Meco Man](https://github.com/mysterywolf)

Homepage: https://github.com/RT-Thread-packages/cJSON

